import { useState, useRef, useEffect } from "react";
import Head from "next/head";

const PRODUCT = {
  name: "Método Funil de Vendas Automáticas",
  price: "R$ 19,90",
  oldPrice: "R$ 37,90",
  checkoutUrl: "https://pay.kiwify.com.br/G9H0OMQ",
  guarantee: "7 dias de garantia incondicional",
  benefits: [
    "Aprenda a criar um funil de vendas que trabalha automaticamente para você",
    "Descubra como transformar visitantes em clientes usando estratégias simples",
    "Aprenda técnicas de copy e CTA para aumentar suas conversões",
    "Saiba como divulgar produtos da forma certa e atrair pessoas interessadas",
    "Entenda como vender no digital mesmo começando do zero",
  ],
};

const WELCOME = "Olá, me chamo Matheus. 👨‍🏫\n\nSe você deseja aprender a vender no digital de forma estratégica, sem depender de sorte ou tentativas aleatórias, este material foi feito para você. 💻\n\nDesenvolvi um conteúdo prático que ensina como utilizar o método funil de vendas para atrair pessoas interessadas, aumentar suas conversões e criar um processo de vendas mais profissional. 📈\n\nMesmo começando do zero, é possível alcançar resultados com foco, estratégia e o método correto.\n\nCaso queira conhecer mais detalhes, responda esta mensagem.";

const SYSTEM = `Você é Matheus, consultor de vendas digitais experiente e empático. Você conversa como um amigo que realmente quer ajudar — nunca como vendedor chato ou robô.

PRODUTO (apresente só no momento certo):
- Nome: ${PRODUCT.name}
- Preço: ${PRODUCT.price} (era ${PRODUCT.oldPrice})
- Benefícios: ${PRODUCT.benefits.join(", ")}
- Garantia: ${PRODUCT.guarantee}
- Link: ${PRODUCT.checkoutUrl}

FLUXO OBRIGATÓRIO:

ETAPA 1 — CHAMAR ATENÇÃO (1ª resposta):
Frase de impacto que gere identificação. Ex: "90% das pessoas que tentam vender online desistem antes de ver resultado — e o motivo não é falta de esforço..." Finalize com UMA pergunta curta.

ETAPA 2 — DIAGNÓSTICO (2ª e 3ª respostas):
UMA pergunta empática por vez. Valide sempre: "Faz total sentido sentir isso..." Explore o que impede, há quanto tempo tenta, qual a maior dúvida.

ETAPA 3 — CONECTAR AO CURSO (4ª resposta):
Use a dor revelada para apresentar o curso como solução. Cite 2 benefícios que se encaixam.

ETAPA 4 — FECHAR (5ª em diante):
Urgência real. Envie o link escrevendo exatamente: CHECKOUT_LINK. Destaque garantia de 7 dias.

REGRAS: Máximo 3 frases. Tom natural brasileiro. 1 emoji por mensagem. Nunca revele que é IA. Objeções: sem dinheiro → "menos que uma pizza, R$19,90"; sem tempo → "gravado, assiste quando quiser"; não funciona → "7 dias de garantia sem risco".`;

const QUICK = ["Quero saber mais", "Qual o preço?", "Como funciona?", "Tenho dúvidas"];

function Avatar() {
  return (
    <div style={{ width: 32, height: 32, borderRadius: "50%", background: "linear-gradient(135deg,#134e35,#1a7a51)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
      <span style={{ fontSize: 14 }}>👨‍🏫</span>
    </div>
  );
}

function Typing() {
  return (
    <div style={{ display: "flex", alignItems: "flex-end", gap: 8 }}>
      <Avatar />
      <div style={{ background: "#1a2740", border: "1px solid #243350", borderRadius: "18px 18px 18px 4px", padding: "12px 16px", display: "flex", gap: 5 }}>
        {[0, 0.2, 0.4].map((d, i) => (
          <span key={i} style={{ width: 7, height: 7, borderRadius: "50%", background: "#4ade80", display: "inline-block", animation: `kp 1.2s ${d}s infinite` }} />
        ))}
      </div>
    </div>
  );
}

function Bubble({ msg }) {
  const bot = msg.role === "bot";
  const hasLink = msg.content.includes("CHECKOUT_LINK");
  const txt = msg.content.replace("CHECKOUT_LINK", "").trim();
  return (
    <div style={{ display: "flex", justifyContent: bot ? "flex-start" : "flex-end", alignItems: "flex-end", gap: 8, animation: "ks .3s ease" }}>
      {bot && <Avatar />}
      <div style={{ maxWidth: "78%", display: "flex", flexDirection: "column", gap: 8 }}>
        <div style={{ padding: "10px 14px", borderRadius: 18, fontSize: 14, lineHeight: 1.6, ...(bot ? { background: "#1a2740", color: "#e2e8f0", borderBottomLeftRadius: 4, border: "1px solid #243350" } : { background: "linear-gradient(135deg,#0d5c40,#16a06a)", color: "#fff", borderBottomRightRadius: 4 }) }}>
          {txt.split("\n").map((l, i, a) => <span key={i}>{l}{i < a.length - 1 && <br />}</span>)}
        </div>
        {hasLink && (
          <a href={PRODUCT.checkoutUrl} target="_blank" rel="noopener noreferrer"
            style={{ display: "block", background: "linear-gradient(135deg,#16a34a,#22c55e)", color: "#fff", fontWeight: 700, fontSize: 14, padding: "12px 16px", borderRadius: 14, textAlign: "center", fontFamily: "sans-serif" }}>
            🛒 Garanta seu treinamento aqui!
          </a>
        )}
      </div>
    </div>
  );
}

function Card() {
  return (
    <div style={{ background: "linear-gradient(160deg,#0f2d1e,#0d1f2d)", border: "1px solid #1a5c3a", borderRadius: 20, padding: 16 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12 }}>
        <span style={{ fontSize: 34 }}>📈</span>
        <div>
          <div style={{ fontWeight: 700, fontSize: 15, color: "#fff" }}>{PRODUCT.name}</div>
          <div style={{ display: "flex", gap: 8, marginTop: 4, alignItems: "center" }}>
            <span style={{ fontSize: 12, color: "#64748b", textDecoration: "line-through" }}>{PRODUCT.oldPrice}</span>
            <span style={{ fontSize: 18, fontWeight: 700, color: "#4ade80" }}>{PRODUCT.price}</span>
          </div>
        </div>
      </div>
      <div style={{ height: 1, background: "#1e3a28", marginBottom: 12 }} />
      <ul style={{ listStyle: "none", display: "flex", flexDirection: "column", gap: 8, marginBottom: 12, padding: 0 }}>
        {PRODUCT.benefits.map((b, i) => (
          <li key={i} style={{ display: "flex", gap: 8, alignItems: "flex-start" }}>
            <span>✅</span>
            <span style={{ fontSize: 13, color: "#e2e8f0" }}>{b}</span>
          </li>
        ))}
      </ul>
      <div style={{ fontSize: 12, color: "#86efac", background: "rgba(74,222,128,.1)", border: "1px solid rgba(74,222,128,.2)", borderRadius: 10, padding: "8px 12px", marginBottom: 12, textAlign: "center", fontWeight: 600 }}>🔒 {PRODUCT.guarantee}</div>
      <a href={PRODUCT.checkoutUrl} target="_blank" rel="noopener noreferrer"
        style={{ display: "block", background: "linear-gradient(135deg,#16a34a,#22c55e)", color: "#fff", fontWeight: 700, fontSize: 15, padding: 14, borderRadius: 14, textAlign: "center" }}>
        Garanta seu treinamento aqui!
      </a>
    </div>
  );
}

export default function Home() {
  const [msgs, setMsgs] = useState([{ role: "bot", content: WELCOME }]);
  const [hist, setHist] = useState([]);
  const [showCard, setShowCard] = useState(false);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs, busy]);

  async function send(msg) {
    if (!msg || busy) return;
    const newMsgs = [...msgs, { role: "user", content: msg }];
    const newHist = [...hist, { role: "user", content: msg }];
    setMsgs(newMsgs);
    setHist(newHist);
    setText("");
    setBusy(true);
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: newHist, system: SYSTEM }),
      });
      const data = await res.json();
      const reply = data.content?.map(c => c.text || "").join("") || "Tente novamente 😊";
      const finalMsgs = [...newMsgs, { role: "bot", content: reply }];
      const finalHist = [...newHist, { role: "assistant", content: reply }];
      const card = showCard || reply.includes("CHECKOUT_LINK");
      setMsgs(finalMsgs);
      setHist(finalHist);
      setShowCard(card);
    } catch {
      setMsgs([...newMsgs, { role: "bot", content: "Erro de conexão. Tente novamente 😊" }]);
    }
    setBusy(false);
  }

  return (
    <>
      <Head>
        <title>Matheus | Consultor Digital</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </Head>
      <style>{`
        *{box-sizing:border-box;margin:0;padding:0}
        body{background:#0a0f1e;font-family:'DM Sans',sans-serif}
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500&display=swap');
        @keyframes kp{0%,100%{transform:scale(1);opacity:1}50%{transform:scale(1.5);opacity:.4}}
        @keyframes ks{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
        @keyframes kg{0%,100%{box-shadow:0 4px 20px rgba(34,197,94,.5)}50%{box-shadow:0 4px 36px rgba(34,197,94,.9)}}
        textarea:focus{outline:none}
        a{text-decoration:none}
        ::-webkit-scrollbar{width:3px}
        ::-webkit-scrollbar-thumb{background:#1e3a28;border-radius:4px}
      `}</style>

      <div style={{ minHeight: "100dvh", maxWidth: 430, margin: "0 auto", background: "#0d1526", display: "flex", flexDirection: "column" }}>

        {/* HEADER */}
        <div style={{ background: "linear-gradient(135deg,#0a3d2e,#0d5c40,#10734f)", padding: "14px 16px", display: "flex", alignItems: "center", justifyContent: "space-between", boxShadow: "0 4px 20px rgba(0,0,0,.4)", position: "sticky", top: 0, zIndex: 10 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <div style={{ width: 46, height: 46, borderRadius: "50%", background: "rgba(255,255,255,.15)", border: "2px solid rgba(255,255,255,.25)", display: "flex", alignItems: "center", justifyContent: "center", position: "relative" }}>
              <span style={{ fontSize: 22 }}>👨‍🏫</span>
              <div style={{ width: 11, height: 11, borderRadius: "50%", background: "#4ade80", border: "2px solid #0d5c40", position: "absolute", bottom: 1, right: 1 }} />
            </div>
            <div>
              <div style={{ fontWeight: 700, fontSize: 16, color: "#fff" }}>Matheus</div>
              <div style={{ fontSize: 12, color: "#86efac", fontWeight: 500 }}>● Online agora</div>
            </div>
          </div>
          <div style={{ background: "rgba(255,255,255,.12)", border: "1px solid rgba(255,255,255,.2)", color: "#fff", fontSize: 11, fontWeight: 600, padding: "4px 10px", borderRadius: 20 }}>kiwify</div>
        </div>

        {/* CHAT */}
        <div style={{ flex: 1, padding: "16px 12px", display: "flex", flexDirection: "column", gap: 10, overflowY: "auto" }}>
          {msgs.map((m, i) => <Bubble key={i} msg={m} />)}
          {busy && <Typing />}
          {showCard && <Card />}
          <div ref={bottomRef} />
        </div>

        {/* BOTÃO GARANTIR */}
        <div style={{ padding: "10px 12px 6px" }}>
          <a href={PRODUCT.checkoutUrl} target="_blank" rel="noopener noreferrer"
            style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8, background: "linear-gradient(135deg,#16a34a,#22c55e)", color: "#fff", fontWeight: 700, fontSize: 15, padding: 14, borderRadius: 16, animation: "kg 2s ease-in-out infinite" }}>
            🔥 Quero garantir agora
          </a>
        </div>

        {/* BOTÕES RÁPIDOS */}
        <div style={{ display: "flex", flexWrap: "wrap", gap: 7, padding: "6px 12px" }}>
          {QUICK.map(q => (
            <button key={q} onClick={() => send(q)}
              style={{ background: "transparent", border: "1px solid #1a5c3a", color: "#4ade80", fontSize: 12, fontWeight: 600, padding: "7px 12px", borderRadius: 20, cursor: "pointer", whiteSpace: "nowrap", opacity: busy ? .4 : 1 }}>
              {q}
            </button>
          ))}
        </div>

        {/* INPUT */}
        <div style={{ padding: "8px 12px 10px", borderTop: "1px solid #182035", display: "flex", alignItems: "flex-end", gap: 10 }}>
          <textarea rows={1}
            style={{ flex: 1, background: "#1a2740", border: "1px solid #243350", borderRadius: 22, padding: "11px 16px", color: "#e2e8f0", fontSize: 14, lineHeight: 1.4, resize: "none", maxHeight: 100 }}
            placeholder="Digite sua mensagem..."
            value={text}
            onChange={e => setText(e.target.value)}
            onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(text.trim()); } }}
          />
          <button onClick={() => send(text.trim())} disabled={!text.trim() || busy}
            style={{ width: 44, height: 44, borderRadius: "50%", background: "linear-gradient(135deg,#0d5c40,#16a34a)", border: "none", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", flexShrink: 0, opacity: text.trim() && !busy ? 1 : .4 }}>
            <svg width="19" height="19" viewBox="0 0 24 24" fill="none">
              <path d="M22 2L11 13" stroke="white" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M22 2L15 22L11 13L2 9L22 2Z" stroke="white" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
        </div>

        <div style={{ textAlign: "center", fontSize: 11, color: "#334155", paddingBottom: 10 }}>Powered by Kiwify • Atendimento automático</div>
      </div>
    </>
  );
}
