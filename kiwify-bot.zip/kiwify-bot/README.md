# 🤖 Kiwify Sales Bot — Matheus

## Como publicar na Vercel (passo a passo)

### 1. Crie uma conta gratuita
Acesse: https://vercel.com e clique em "Sign Up"

### 2. Instale o GitHub Desktop (opcional mas mais fácil)
Acesse: https://desktop.github.com

### 3. Suba o projeto
- Crie uma conta no GitHub (github.com)
- Crie um repositório novo chamado "kiwify-bot"
- Faça upload de todos os arquivos desta pasta

### 4. Importe na Vercel
- Na Vercel, clique em "Add New Project"
- Conecte seu GitHub
- Selecione o repositório "kiwify-bot"
- Clique em "Deploy"

### 5. Configure a chave da API
Na Vercel, vá em:
Settings → Environment Variables → Add New

Nome: ANTHROPIC_API_KEY
Valor: (sua chave do console.anthropic.com)

### 6. Redeploy
Após adicionar a variável, clique em "Redeploy"

### 7. Copie o link
A Vercel vai gerar um link tipo: https://kiwify-bot.vercel.app
Coloque esse link na bio do TikTok!

---
Chave da API: https://console.anthropic.com/settings/keys
